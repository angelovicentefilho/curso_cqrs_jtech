package br.com.jtech.cloud.user.query.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserQueryApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
