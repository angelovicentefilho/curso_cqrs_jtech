package br.com.jtech.cloud.user.command.api;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserCommandApiApplicationTests {

	@Test
	void contextLoads() {
	}

}
