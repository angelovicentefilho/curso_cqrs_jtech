package br.com.jtech.cloud.user.core;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UserCoreApplication {

	public static void main(String[] args) {
		SpringApplication.run(UserCoreApplication.class, args);
	}

}
